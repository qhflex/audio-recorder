/*
 * Copyright (c) 2015-2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/** ============================================================================
 *  @file       CC2640R2DK_5MM.h
 *
 *  @brief      CC2640R2DK_5MM Board Specific header file.
 *
 *  The CC2640R2DK_5MM header file should be included in an application as
 *  follows:
 *  @code
 *  #include "CC2640R2DK_5MM.h"
 *  @endcode
 *
 *  This board file is made for the 5x5 mm QFN package, to convert this board
 *  file to use for other smaller device packages please refer to the table
 *  below which lists the max IOID values supported by each package. All other
 *  unused pins should be set to IOID_UNUSED.
 *
 *  Furthermore the board file is also used
 *  to define a symbol that configures the RF front end and bias.
 *  See the comments below for more information.
 *  For an in depth tutorial on how to create a custom board file, please refer
 *  to the section "Running the SDK on Custom Boards" with in the Software
 *  Developer's Guide.
 *
 *  Refer to the datasheet for all the package options and IO descriptions:
 *  http://www.ti.com/lit/ds/symlink/cc2640r2f.pdf
 *
 *  +-----------------------+------------------+-----------------------+
 *  |     Package Option    |  Total GPIO Pins |   MAX IOID            |
 *  +=======================+==================+=======================+
 *  |     7x7 mm QFN        |     31           |   IOID_30             |
 *  +-----------------------+------------------+-----------------------+
 *  |     5x5 mm QFN        |     15           |   IOID_14             |
 *  +-----------------------+------------------+-----------------------+
 *  |     4x4 mm QFN        |     10           |   IOID_9              |
 *  +-----------------------+------------------+-----------------------+
 *  |     2.7 x 2.7 mm WCSP |     14           |   IOID_13             |
 *  +-----------------------+------------------+-----------------------+
 *  ============================================================================
 */
#ifndef __CC2640R2DK_5MM_BOARD_H__
#define __CC2640R2DK_5MM_BOARD_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes */
#include <ti/drivers/PIN.h>
#include <ti/devices/cc26x0r2/driverlib/ioc.h>

/* Externs */
extern const PIN_Config BoardGpioInitTable[];

/* Defines */
#ifndef CC2640R2DK_5MM
  #define CC2640R2DK_5MM
#endif /* CC2640R2DK_5MM */

/*
 *  ============================================================================
 *  RF Front End and Bias configuration symbols for TI reference designs and
 *  kits. This symbol sets the RF Front End configuration in ble_user_config.h
 *  and selects the appropriate PA table in ble_user_config.c.
 *  Other configurations can be used by editing these files.
 *
 *  Define only one symbol:
 *  CC2650EM_7ID    - Differential RF and internal biasing
                      (default for CC2640R2 LaunchPad)
 *  CC2650EM_5XD    � Differential RF and external biasing
 *  CC2650EM_4XS    � Single-ended RF on RF-P and external biasing
 *  CC2640R2DK_CXS  - WCSP: Single-ended RF on RF-N and external biasing
 *                    (Note that the WCSP is only tested and characterized for
 *                     single ended configuration, and it has a WCSP-specific
 *                     PA table)
 *
 *  Note: CC2650EM_xxx reference designs apply to all CC26xx devices.
 *  ==========================================================================
 */
#define CC2650EM_5XD

/* Mapping of pins to board signals using general board aliases
 *      <board signal alias>                <pin mapping>
 */

/* Button Board */
#define CC2640R2DK_5MM_KEY_POWER                     IOID_0
#define CC2640R2DK_5MM_KEY_SELECT                    PIN_UNASSIGNED
#define CC2640R2DK_5MM_KEY_UP                        PIN_UNASSIGNED
#define CC2640R2DK_5MM_KEY_DOWN                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_KEY_LEFT                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_KEY_RIGHT                     PIN_UNASSIGNED

/* GPIO */
#define CC2640R2DK_5MM_GPIO_LED_ON                   1
#define CC2640R2DK_5MM_GPIO_LED_OFF                  0

/* I2S Select */
#define CC2640R2DK_5MM_I2S_SELECT                    IOID_2

/* I2S */
#define CC2640R2DK_5MM_I2S_ADO                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_I2S_ADI                       IOID_4
#define CC2640R2DK_5MM_I2S_BCLK                      IOID_3
#define CC2640R2DK_5MM_I2S_MCLK                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_I2S_WCLK                      IOID_1

/* LEDs */
#define CC2640R2DK_5MM_PIN_LED_ON                    1
#define CC2640R2DK_5MM_PIN_LED_OFF                   0
#define CC2640R2DK_5MM_PIN_LED1                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_PIN_LED2                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_PIN_LED3                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_PIN_LED4                      PIN_UNASSIGNED

/* LCD  Board */
#define CC2640R2DK_5MM_LCD_MODE                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_LCD_RST                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_LCD_CSN                       PIN_UNASSIGNED

/* SPI */
#define CC2640R2DK_5MM_SPI_FLASH_CS                  IOID_8
#define CC2640R2DK_5MM_SPI_FLASH_CS_ON               0
#define CC2640R2DK_5MM_SPI_FLASH_CS_OFF              1
#define CC2640R2DK_5MM_SPI_FLASH_RESET               IOID_9
#define CC2640R2DK_5MM_SPI_FLASH_WP                  IOID_10

/* SPI Board */
#define CC2640R2DK_5MM_SPI0_MISO                     IOID_11
#define CC2640R2DK_5MM_SPI0_MOSI                     IOID_12
#define CC2640R2DK_5MM_SPI0_CLK                      IOID_13
#define CC2640R2DK_5MM_SPI0_CSN                      PIN_UNASSIGNED

/* Power Board */
#define CC2640R2DK_5MM_3V3_EN                        PIN_UNASSIGNED
#define CC2640R2DK_5MM_1V8_EN                        IOID_14

/* PWM Outputs */
#define CC2640R2DK_5MM_PWMPIN0                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN1                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN2                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN3                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN4                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN5                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN6                       PIN_UNASSIGNED
#define CC2640R2DK_5MM_PWMPIN7                       PIN_UNASSIGNED

/* UART Board */
#define CC2640R2DK_5MM_UART_RX                       IOID_7             // TDI, pin close to RST on customer's 7 pin interface
#define CC2640R2DK_5MM_UART_TX                       IOID_6             // TDO, pin close to TCK on customer's 7 pin interface
#define CC2640R2DK_5MM_UART_CTS                      PIN_UNASSIGNED
#define CC2640R2DK_5MM_UART_RTS                      PIN_UNASSIGNED

/*!
 *  @brief  Initialize the general board specific settings
 *
 *  This function initializes the general board specific settings.
 */
void CC2640R2DK_5MM_initGeneral(void);

/*!
 *  @def    CC2640R2DK_5MM_CryptoName
 *  @brief  Enum of Crypto names
 */
typedef enum CC2640R2DK_5MM_CryptoName {
    CC2640R2DK_5MM_CRYPTO0 = 0,

    CC2640R2DK_5MM_CRYPTOCOUNT
} CC2640R2DK_5MM_CryptoName;

/*!
 *  @def    CC2640R2DK_5MM_GPIOName
 *  @brief  Enum of GPIO names
 */
typedef enum CC2640R2DK_5MM_GPIOName {
    CC2640R2DK_5MM_GPIO_S1,
    CC2640R2DK_5MM_GPIO_I2S_SELECT,
    CC2640R2DK_5MM_GPIO_SPI_FLASH_CS,
    CC2640R2DK_5MM_GPIO_SPI_FLASH_RESET,
    CC2640R2DK_5MM_GPIO_SPI_FLASH_WP,
    CC2640R2DK_5MM_GPIO_1V8_EN,
    CC2640R2DK_5MM_GPIOCOUNT
} CC2640R2DK_5MM_GPIOName;

/*!
 *  @def    CC2640R2DK_5MM_GPTimerName
 *  @brief  Enum of GPTimer parts
 */
typedef enum CC2640R2DK_5MM_GPTimerName {
//    CC2640R2DK_5MM_GPTIMER0A = 0,
//    CC2640R2DK_5MM_GPTIMER0B,
//    CC2640R2DK_5MM_GPTIMER1A,
//    CC2640R2DK_5MM_GPTIMER1B,
//    CC2640R2DK_5MM_GPTIMER2A,
//    CC2640R2DK_5MM_GPTIMER2B,
//    CC2640R2DK_5MM_GPTIMER3A,
//    CC2640R2DK_5MM_GPTIMER3B,

    CC2640R2DK_5MM_GPTIMERPARTSCOUNT
} CC2640R2DK_5MM_GPTimerName;

/*!
 *  @def    CC2640R2DK_5MM_GPTimers
 *  @brief  Enum of GPTimers
 */
typedef enum CC2640R2DK_5MM_GPTimers {
//    CC2640R2DK_5MM_GPTIMER0 = 0,
//    CC2640R2DK_5MM_GPTIMER1,
//    CC2640R2DK_5MM_GPTIMER2,
//    CC2640R2DK_5MM_GPTIMER3,

    CC2640R2DK_5MM_GPTIMERCOUNT
} CC2640R2DK_5MM_GPTimers;

/*!
 *  @def    CC2640R2DK_5MM_I2SName
 *  @brief  Enum of I2S names
 */
typedef enum CC2640R2DK_5MM_I2SName {
    CC2640R2DK_5MM_I2S0 = 0,

    CC2640R2DK_5MM_I2SCOUNT
} CC2640R2DK_5MM_I2SName;

/*!
 *  @def    CC2640R2DK_5MM_NVSName
 *  @brief  Enum of NVS names
 */
typedef enum CC2640R2DK_5MM_NVSName {
#ifndef Board_EXCLUDE_NVS_INTERNAL_FLASH
    CC2640R2DK_5MM_NVSCC26XX0 = 0,
#endif
#ifndef Board_EXCLUDE_NVS_EXTERNAL_FLASH
    CC2640R2DK_5MM_NVSSPI25X0,
#endif

    CC2640R2DK_5MM_NVSCOUNT
} CC2640R2DK_5MM_NVSName;

/*!
 *  @def    CC2640R2DK_5MM_PWM
 *  @brief  Enum of PWM outputs
 */
typedef enum CC2640R2DK_5MM_PWMName {
//    CC2640R2DK_5MM_PWM0 = 0,
//    CC2640R2DK_5MM_PWM1,
//    CC2640R2DK_5MM_PWM2,
//    CC2640R2DK_5MM_PWM3,
//    CC2640R2DK_5MM_PWM4,
//    CC2640R2DK_5MM_PWM5,
//    CC2640R2DK_5MM_PWM6,
//    CC2640R2DK_5MM_PWM7,

    CC2640R2DK_5MM_PWMCOUNT
} CC2640R2DK_5MM_PWMName;

/*!
 *  @def    CC2640R2DK_5MM_SPIName
 *  @brief  Enum of SPI names
 */
typedef enum CC2640R2DK_5MM_SPIName {
    CC2640R2DK_5MM_SPI0 = 0,

    CC2640R2DK_5MM_SPICOUNT
} CC2640R2DK_5MM_SPIName;

/*!
 *  @def    CC2640R2DK_5MM_UARTName
 *  @brief  Enum of UARTs
 */
typedef enum CC2640R2DK_5MM_UARTName {
    CC2640R2DK_5MM_UART0 = 0,

    CC2640R2DK_5MM_UARTCOUNT
} CC2640R2DK_5MM_UARTName;

/*!
 *  @def    CC2640R2DK_5MM_UDMAName
 *  @brief  Enum of DMA buffers
 */
typedef enum CC2640R2DK_5MM_UDMAName {
    CC2640R2DK_5MM_UDMA0 = 0,

    CC2640R2DK_5MM_UDMACOUNT
} CC2640R2DK_5MM_UDMAName;

/*!
 *  @def    CC2640R2DK_5MM_WatchdogName
 *  @brief  Enum of Watchdogs
 */
typedef enum CC2640R2DK_5MM_WatchdogName {
    CC2640R2DK_5MM_WATCHDOG0 = 0,

    CC2640R2DK_5MM_WATCHDOGCOUNT
} CC2640R2DK_5MM_WatchdogName;

/*!
 *  @def    CC2650_LAUNCHXL_TRNGName
 *  @brief  Enum of TRNG names on the board
 */
typedef enum CC2640R2DK_5MM_TRNGName {
    CC2640R2DK_5MM_TRNG0 = 0,
    CC2640R2DK_5MM_TRNGCOUNT
} CC2640R2DK_5MM_TRNGName;

#ifdef __cplusplus
}
#endif

#endif /* __CC2640R2DK_5MM_BOARD_H__ */
